package brickbreaker;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServerThread extends Thread{
	private ObjectInputStream in;
	private ObjectOutputStream out;
	
	ServerThread(Socket s) {
		try {
			out = new ObjectOutputStream(s.getOutputStream());
			in = new ObjectInputStream(s.getInputStream());
			
			this.start();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		while (true) {
			try {
				int code = in.readInt();
				System.out.println("past code read");
				if (code == 1) { // Confirmation of log in 
					String username = (String) in.readObject();
					String password = (String) in.readObject();
					
					boolean check = Database.logIn(username, password);
					
					out.writeObject(check);
					out.flush();
				}
				
				else if (code == 2) { // confirmation of sign up 
					String username = (String) in.readObject();
					String password = (String) in.readObject();
					String confirmPassword = (String) in.readObject();
					
					String check = Database.signUp(username, password, confirmPassword);
					
					out.writeObject(check);
					out.flush();
				}
				
				else if (code == 3) { // returns stored highscore for user 
					String username = (String) in.readObject();
					String difficulty = (String) in.readObject();
					
					int score = Database.getHighscore(username, difficulty);
					
					out.writeInt(score);
					out.flush();
				}
				
				else if (code == 4) { // sets new highscore for user
					System.out.println("inside code 4");
					String username = (String) in.readObject();
					System.out.println("read username");
					String difficulty = (String) in.readObject();
					System.out.println("read difficulty");
					int score = in.readInt();
					System.out.println("read score");
					
					Database.setHighscore(username, difficulty, score);
				}
			} 
			catch (IOException ioe) {
				System.out.println("ioe: " + ioe.getMessage());
				break;
			}
			catch(ClassNotFoundException ce) {
				System.out.println("ce: " + ce.getMessage());
				break;
			}
			
		}
	}
}
