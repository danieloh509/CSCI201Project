package brickbreaker;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JFrame;

public class Main {
	private JFrame app;
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;
	
	private String name; 
	private String level;
	private int levelInt;
	private int soloInt;
	
	private ExecutorService pool = Executors.newFixedThreadPool(1);
	
	private boolean guest = false;
	private boolean MainMenu = true;
	private boolean ChangeDifficulty = true;
	private boolean solo = true;
	
	public Main(ObjectOutputStream out, ObjectInputStream in) {
		app = new JFrame("brickbreaker");
	
		app.setVisible(true);
		app.setBounds(50, 50, WIDTH, HEIGHT);
		app.setResizable(false);
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Login Log = new Login(out, in); 
		app.add(Log);
		app.validate();
		
		while(!Log.getDone()) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	
		if (Log.getUser()) {
			app.remove(Log);
			
			SignUp NewUser = new SignUp(out, in);
			app.add(NewUser);
			app.validate();
			
			while(!NewUser.getDone()) {
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			name = NewUser.getName();
			app.remove(NewUser);
		}
		
		else if (Log.isGuest()) {
			name = "Guest";
			guest = true;
			app.remove(Log);
		}
		
		else {
			name = Log.getname();
			app.remove(Log);
		}

		while (true) {
			if (MainMenu && !guest) { 
				ModeSelect modeScreen = new ModeSelect();
				app.add(modeScreen);
				app.validate();
				
				while (!modeScreen.getDone()) {//all code relating to the Main Menu screen should be put here
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				String mode= modeScreen.modeSelect();
				
				if (mode.equalsIgnoreCase("multi")) {
					solo = false;
				}
				
				else if (mode.equalsIgnoreCase("solo")) {
					solo = true;
				}
				app.remove(modeScreen);
				// wrote this code assuming we are not making multiplayer option 
			}
			
			if (ChangeDifficulty) {
				Difficulty difficultyScreen = new Difficulty();
				app.add(difficultyScreen);
				app.validate();
				
				while (!difficultyScreen.isNextScreen()) {
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				level = difficultyScreen.getLevel();
				app.remove(difficultyScreen);
				// all code relating to the change difficulty screen should be put here 
				
				//this includes a dding anf removing the panle form JFrame
			}
	
			// insert calling the game code here, before the highscore
			//this area should include removing the game screen from view
			if (level.equalsIgnoreCase("easy")) {
				levelInt = 1;
			}
			
			else if(level.equalsIgnoreCase("medium")) {
				levelInt = 2;
			}
			
			else if (level.equalsIgnoreCase("hard")) {
				levelInt = 3;
			}
			
			if (solo) {
				soloInt = 1;
			}
			
			else {
				soloInt = 2;
			}
			
			pls.BrickBreaker game = new pls.BrickBreaker(levelInt, soloInt);
			
			pool.execute(game);
			
			while(game.running()) {
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			Highscore score = new Highscore(game.getScore(), name, level, out, in, solo);
			
			app.add(score);
			app.validate();
			
			while (!score.isNextScreen()) { // keeps on looping until button is clicked
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			if (score.isMainMenuScreen()) { // if main menu button was clicked
				MainMenu = true;
				ChangeDifficulty = true;
			}
			else if (score.isDifficultyScreen()) { // if change difficulty was clicked
				MainMenu = false;
				ChangeDifficulty = true;
			}
			else if (score.isGameScreen()) { // if play again was clicked
				MainMenu = false;
				ChangeDifficulty = false;
			}
			app.remove(score);
		}
	}
	
	public static void main(String[] args) {
		try {
			Socket s = new Socket("localhost",6789);
			ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
			ObjectInputStream in = new ObjectInputStream(s.getInputStream());
				
			new Main(out, in);
		} 
		catch (UnknownHostException e1) {
			e1.printStackTrace();
		} 
		catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
