package brickbreaker;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JPanel implements KeyListener, ActionListener{
	private BufferedImage image;
	private JLabel title;
	private JLabel usernameLabel;
	private JTextField usernameField;
	private JLabel passwordLabel;
	private JPasswordField passwordField;
	private JLabel loginError;
	private JButton loginButton;
	private JButton signUpButton;
	private JButton guestButton;
	private boolean newuser;
	private boolean done = false;
	private boolean isGuest = false;
	private String name = null;
	
	public Login(ObjectOutputStream out, ObjectInputStream in) {
		newuser = false;
		isGuest = false;
		done = false;
		this.setLayout(null);
		this.setBackground(Color.black);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		setFields(out, in);
		this.add(title);
		this.add(usernameLabel);
		this.add(usernameField);
		this.add(passwordLabel);
		this.add(passwordField);
		this.add(loginButton);
		this.add(signUpButton);
		this.add(guestButton);
		this.add(loginError);
		loginError.setVisible(false);
	}

	private void setFields(ObjectOutputStream out, ObjectInputStream in) {
		try {
			image = ImageIO.read(new File("BrickBreaker.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		title = new JLabel(new ImageIcon(image));
		title.setBounds(-180, 80, 1000, 100);
		usernameLabel = new JLabel("<html><font size='3' color=white> Username</font></html>");
		usernameLabel.setBounds(210, 180, 150, 25);
		usernameField = new JTextField();
		usernameField.setBounds(270, 180, 150, 25);
		usernameField.setColumns(10);
		passwordLabel = new JLabel("<html><font size='3' color=white> Password</font></html>");
		passwordLabel.setBounds(210, 230, 150, 25);
		passwordField = new JPasswordField();
		passwordField.setBounds(270, 230, 150, 25);
		passwordField.setColumns(10);
		loginError = new JLabel("<html><font size='3' color=red> Invalid Username or Password</font></html>");
		loginError.setBounds(380, 280, 200, 25);
		loginButton = new JButton("Login");
		loginButton.setBounds(270, 280, 100, 25);
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = usernameField.getText();
				String password = passwordField.getText();
				name = username;
		
				try {
					out.writeInt(1);
					out.flush();
					
					out.writeObject(username);
					out.flush();
					
					out.writeObject(password);
					out.flush();
					
					boolean check = (boolean) in.readObject();
					
					if(check) {
						done = true;
					}
					else {
						loginError.setVisible(true);
					}
				} catch (IOException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		});
		
		signUpButton = new JButton("Sign Up");
		signUpButton.setBounds(270, 320, 100, 25);
		signUpButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				newuser = true;
				done = true;
			}
		});
		
		guestButton = new JButton("Play as Guest");
		guestButton.setBounds(245, 360, 150, 25);
		guestButton.setFont(new Font("Serif",Font.BOLD,12));
		guestButton.setBackground(Color.black);
		guestButton.setForeground(Color.WHITE);
		guestButton.setFocusPainted(false);
		guestButton.setBorderPainted(false);
		guestButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				isGuest = true;
				done = true;
			}
		});
	}
	
	public boolean getDone() {
		return done;
	}
	
	public boolean getUser() {
		return newuser;
	}
	
	public boolean isGuest() {
		return isGuest;
	}
	
	public String getname() {
		return name;
	}

	public void actionPerformed(ActionEvent arg0) {
		
	}

	public void keyPressed(KeyEvent arg0) {
		
	}

	public void keyReleased(KeyEvent arg0) {
		
	}

	public void keyTyped(KeyEvent arg0) {
		
	}
}
