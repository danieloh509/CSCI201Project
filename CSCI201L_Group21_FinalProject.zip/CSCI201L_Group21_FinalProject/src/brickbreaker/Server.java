package brickbreaker;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class Server {
	public Vector<ServerThread> serverThreads;
	
	public Server() {
		try {
			ServerSocket ss = new ServerSocket(6789);
			serverThreads = new Vector<ServerThread>();
			
			while (true) {
				Socket dConnect = ss.accept();
				ServerThread serverThread = new ServerThread(dConnect); 
				serverThreads.add(serverThread);
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String [] args) {
		new Server();
	}
}
