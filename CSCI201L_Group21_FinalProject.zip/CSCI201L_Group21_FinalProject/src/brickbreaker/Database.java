package brickbreaker;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database {
	
	public static boolean logIn(String username, String password) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection conn = null;
			PreparedStatement ps =null;
			ResultSet rs = null;
			
			conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/F2GCT4gVsA?user=F2GCT4gVsA&password=fYBU5EacV2");
			ps = conn.prepareStatement("SELECT* FROM Users WHERE Username=?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			if (rs.next() == false) { // username does not exist in data 
				System.out.println("username does not exist in data");
				conn.close();
				return false;
			}
			
			else if (password.equals(rs.getString("Password"))) { // given password matches password in database 
				System.out.println("password was correct");
				conn.close();
				return true;
			}
			
			else { // password doesn't match
				System.out.println("password was incorrect");
				conn.close();
				return false;	
			}
		} 
		catch (ClassNotFoundException ce) {
			System.out.println ("ClassNotFoundException: " + ce.getMessage());
			return false;
		} 
		catch(SQLException sqle) {
			System.out.println ("SQLException: " + sqle.getMessage());
			return false;
		}
	}
	
	public static String signUp(String username, String password, String confirmPassword) {
		if(password.compareTo(confirmPassword) != 0) {
			return "Passwords do not match";
		}
		
		if(username.length() == 0 || password.length() == 0) {
			return "Must enter username or password";
		}
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection conn = null;
			PreparedStatement ps =null;
			ResultSet rs = null;
			
			conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/F2GCT4gVsA?user=F2GCT4gVsA&password=fYBU5EacV2");
			ps = conn.prepareStatement("SELECT* FROM Users WHERE Username=?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			if (rs.next() == true) { //username is already being used by another user
				conn.close();
				return "Username is already in use";
			}
			
			else { // adds user information to the database 
				ps.close();
				rs.close();
				
				ps = conn.prepareStatement("INSERT INTO Users(Username, Password, SoloHighscoreEasy, SoloHighscoreMedium, SoloHighscoreHard, "
						+ "MultiHighscoreEasy, MultiHighscoreMedium, MultiHighscoreHard)"
						+ "VALUES(?,?,0,0,0,0,0,0)");
				ps.setString(1, username);
				ps.setString(2, password);
				ps.executeUpdate();
				
				System.out.println("username added");
				conn.close();
				return null;
			}
		}
		catch (ClassNotFoundException ce) {
			System.out.println ("ClassNotFoundException: " + ce.getMessage());
			return "There was an error signing up";
		} 
		catch(SQLException sqle) {
			System.out.println ("SQLException: " + sqle.getMessage());
			return "There was an error signing up";
		}
	}
	
	public static int getHighscore(String username, String difficulty, boolean solo) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection conn = null;
			PreparedStatement ps =null;
			ResultSet rs = null;
		
			conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/F2GCT4gVsA?user=F2GCT4gVsA&password=fYBU5EacV2");
			
			if (difficulty.equalsIgnoreCase("easy")) {
				if (solo) {
					ps = conn.prepareStatement("SELECT SoloHighscoreEasy FROM Users WHERE Username=?");
				}
				else {
					ps = conn.prepareStatement("SELECT MultiHighscoreEasy FROM Users WHERE Username=?");
				}
			}
			
			else if (difficulty.equalsIgnoreCase("medium")) {
				if (solo) {
					ps = conn.prepareStatement("SELECT SoloHighscoreMedium FROM Users WHERE Username=?");
				}
				else {
					ps = conn.prepareStatement("SELECT MultiHighscoreMedium FROM Users WHERE Username=?");
				}
			}
			
			else if(difficulty.equalsIgnoreCase("hard")) {
				if (solo) {
					ps = conn.prepareStatement("SELECT SoloHighscoreHard FROM Users WHERE Username=?");
				}
				else {
					ps = conn.prepareStatement("SELECT MultiHighscoreHard FROM Users WHERE Username=?");
				}
			}
			
			else {
				return -1;
			}
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			rs.next();
			int temp = rs.getInt(1);
			
			conn.close();
			return temp;
		}
		catch (ClassNotFoundException ce) {
			System.out.println ("ClassNotFoundException: " + ce.getMessage());
			return -1;
		} 
		catch(SQLException sqle) {
			System.out.println ("SQLException: " + sqle.getMessage());
			return -1;
		}
	}
	
	public static void setHighscore(String username, String difficulty, int score, boolean solo) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection conn = null;
			PreparedStatement ps =null;
			
			boolean rightDiff = false;
			
			conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/F2GCT4gVsA?user=F2GCT4gVsA&password=fYBU5EacV2");
			
			if (difficulty.equalsIgnoreCase("easy")) {
				if (solo) {
					ps = conn.prepareStatement("UPDATE Users SET SoloHighscoreEasy =? WHERE Username=?");
				}	
				else {
					ps = conn.prepareStatement("UPDATE Users SET MultiHighscoreEasy =? WHERE Username=?");
				}
				rightDiff = true;
			}
			
			else if (difficulty.equalsIgnoreCase("medium")) {
				if (solo) {
					ps = conn.prepareStatement("UPDATE Users SET SoloHighscoreMedium =? WHERE Username=?");
				}
				else {
					ps = conn.prepareStatement("UPDATE Users SET MultiHighscoreMedium =? WHERE Username=?");
				}
				rightDiff = true;
			}
			
			else if(difficulty.equalsIgnoreCase("hard")) {
				if (solo) {
					ps = conn.prepareStatement("UPDATE Users SET SoloHighscoreHard =? WHERE Username=?");
				}
				else {
					ps = conn.prepareStatement("UPDATE Users SET MultiHighscoreHard =? WHERE Username=?");
				}
				rightDiff = true;
			}
			
			if (rightDiff) {
				ps.setInt(1, score);
				ps.setString(2, username);
				ps.executeUpdate();
			}
			conn.close();
		}
		catch (ClassNotFoundException ce) {
			System.out.println ("ClassNotFoundException: " + ce.getMessage());
		} 
		catch(SQLException sqle) {
			System.out.println ("SQLException: " + sqle.getMessage());
		}
	}
}