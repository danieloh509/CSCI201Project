package brickbreaker;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class SignUp extends JPanel implements KeyListener, ActionListener{
	private BufferedImage image;
	private JLabel title;
	private JLabel usernameLabel;
	private JTextField usernameField;
	private JLabel passwordLabel;
	private JPasswordField passwordField;
	private JLabel confirmPasswordLabel;
	private JPasswordField confirmPasswordField;
	private JButton signUpButton;
	private JLabel signUpError;
	private boolean done;
	
	public SignUp() {
		done = false;
		this.setLayout(null);
		this.setBackground(Color.black);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		setFields();
		this.add(title);
		this.add(usernameLabel);
		this.add(usernameField);
		this.add(passwordLabel);
		this.add(passwordField);
		this.add(confirmPasswordLabel);
		this.add(confirmPasswordField);
		this.add(signUpButton);
		signUpError.setVisible(false);
		this.add(signUpError);
	}
	
	private void setFields() {
		try {
			image = ImageIO.read(new File("BrickBreaker.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		title = new JLabel(new ImageIcon(image));
		title.setBounds(-180, 80, 1000, 100);
		
		usernameLabel = new JLabel("<html><font size='3' color=white> Username</font></html>");
		usernameLabel.setBounds(210, 180, 150, 25);
		usernameField = new JTextField();
		usernameField.setBounds(270, 180, 150, 25);
		usernameField.setColumns(10);
		
		passwordLabel = new JLabel("<html><font size='3' color=white> Password</font></html>");
		passwordLabel.setBounds(210, 230, 150, 25);
		passwordField = new JPasswordField();
		passwordField.setBounds(270, 230, 150, 25);
		passwordField.setColumns(10);
		
		confirmPasswordLabel = new JLabel("<html><font size='3' color=white> Confirm Password</font></html>");
		confirmPasswordLabel.setBounds(160, 280, 150, 25);
		confirmPasswordField = new JPasswordField();
		confirmPasswordField.setBounds(270, 280, 150, 25);
		confirmPasswordField.setColumns(10);
		
		signUpError = new JLabel();
		signUpError.setBounds(380, 330, 200, 25);
		
		signUpButton = new JButton("Sign Up");
		signUpButton.setBounds(270, 330, 100, 25);
		signUpButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = usernameField.getText();
				String password = passwordField.getText();
				String confirmPassword = confirmPasswordField.getText();
				String databaseReturn = Database.signUp(username, password, confirmPassword);
				if(databaseReturn == null) {
					done = true;
				}
				else {
					signUpError.setText("<html><font size='3' color=red>" + databaseReturn + "</font></html>");
					signUpError.setVisible(true);
				}
			}
		});
	}

	public void actionPerformed(ActionEvent e) {
		
	}

	public void keyPressed(KeyEvent arg0) {
		
	}

	public void keyReleased(KeyEvent arg0) {
		
	}

	public void keyTyped(KeyEvent arg0) {
		
	}

}
