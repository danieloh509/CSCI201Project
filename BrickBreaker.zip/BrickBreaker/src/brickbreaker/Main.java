package brickbreaker;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		JFrame obj = new JFrame();
		obj.setBounds(200, 100, 1000, 600);
		obj.setTitle("CSCI201L Brick Breaker");
		obj.setResizable(false);
		obj.setVisible(true);
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GameScreen gam = new GameScreen();
		obj.add(gam);
	}
}