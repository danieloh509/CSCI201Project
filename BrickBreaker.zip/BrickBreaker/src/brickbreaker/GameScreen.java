package brickbreaker;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


import javax.swing.JPanel;
import javax.swing.Timer;

public class GameScreen extends JPanel implements KeyListener, ActionListener{
	private paddle p;
	private Timer t;
	private int delay = 8;
	
	public GameScreen() {
		this.p = new paddle(500, 550, 0, 0);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		t = new Timer (delay , this);
		t.start();
	}
	
	
	public void paint(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(1, 1, 1000, 1000);
		
		g.setColor(Color.blue);
		g.fillRect(p.hposition, p.vposition, 50, 10);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		t.start();
		repaint();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT){
			if (p.hposition >= (1000-50)) {
				p.hposition = (1000-50);
			}
			else {
				p.hposition += 20;
			}
		}
		else if (e.getKeyCode() == KeyEvent.VK_LEFT){
			if (p.hposition <= 0) {
				p.hposition = 0;
			}
			else {
				p.hposition -= 20;
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		
	}
	
	public static class paddle {
		public int hposition;
		public int vposition;
		public int xdirection;
		public int ydirection;
		
		paddle (int h, int v, int x, int y){
			this.hposition = h;
			this.vposition = v;
			this.xdirection = x;
			this.ydirection = y;
		}
		
	}
	

}
