package brickbreaker;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class signup extends JPanel implements KeyListener, ActionListener{
	private BufferedImage image;
	private JLabel title;
	private JLabel username;
	private JTextField user;
	private JLabel password;
	private JPasswordField pass;
	private JButton signup;
	private boolean done;
	
	public signup() {
		done = false;
		this.setLayout(null);
		this.setBackground(Color.black);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		setFields();
		this.add(title);
		this.add(username);
		this.add(user);
		this.add(password);
		this.add(pass);
		this.add(signup);
	}
	
	private void setFields() {
		try {
			image = ImageIO.read(new File("BrickBreaker.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		title = new JLabel(new ImageIcon(image));
		title.setBounds(-180, 80, 1000, 100);
		username = new JLabel("<html><font size='3' color=white> Username</font></html>");
		username.setBounds(210, 180, 150, 25);
		user = new JTextField();
		user.setBounds(280, 180, 150, 25);
		user.setColumns(10);
		password = new JLabel("<html><font size='3' color=white> Password</font></html>");
		password.setBounds(210, 230, 150, 25);
		pass = new JPasswordField();
		pass.setBounds(280, 230, 150, 25);
		pass.setColumns(10);
		signup = new JButton("Sign Up");
		signup.setBounds(270, 280, 100, 25);
		signup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = user.getText();
				String password = pass.getText();
				done = true;
			}
		});
	}

	public void actionPerformed(ActionEvent e) {
		
	}

	public void keyPressed(KeyEvent arg0) {
		
	}

	public void keyReleased(KeyEvent arg0) {
		
	}

	public void keyTyped(KeyEvent arg0) {
		
	}

}
