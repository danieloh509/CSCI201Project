package brickbreaker;

import javax.swing.*;
import java.awt.*;

public class Main {
	private JFrame app;
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;
	
	public Main() {
		app = new JFrame("brickbreaker");
		login Log = new login();
		app.setVisible(true);
		app.setBounds(50, 50, WIDTH, HEIGHT);
		app.setResizable(false);
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		app.add(Log);
		while(Log.getDone() != true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("test");
		if (Log.getUser() == true) {
			signup NewUser = new signup();
			app.remove(Log);
			app.add(NewUser);
			app.validate();
		}
	}
	
	public static void main(String[] args) {
		new Main();
	}
}
