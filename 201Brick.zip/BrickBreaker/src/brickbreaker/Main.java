package brickbreaker;

import javax.swing.*;
import java.awt.*;

public class Main {
	private JFrame app;
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;
	
	public Main() {
		app = new JFrame("brickbreaker");
		login Log = new login();
		app.setVisible(true);
		app.setBounds(50, 50, WIDTH, HEIGHT);
		app.setResizable(false);
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		app.add(Log);
	}
	
	public static void main(String[] args) {
		new Main();
	}
}
