package brickbreaker;

import javax.swing.*;
import java.awt.*;

public class Main {
	private JFrame app;
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;
	private boolean guest;
	private String name;
	
	public Main() {
		app = new JFrame("brickbreaker");
		Login login = new Login();
		app.setVisible(true);
		app.setBounds(50, 50, WIDTH, HEIGHT);
		app.setResizable(false);
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		app.add(login);
		while(login.getDone() != true) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		app.remove(login);
		if (login.isGuest() == true) {
			guest = true;
		}
		else {
			name = "Guest";
			guest = false;
		}
		if (login.getUser() == true) {
			SignUp NewUser = new SignUp();
			app.add(NewUser);
			app.validate();
			while(NewUser.getDone() != true) {
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			name = NewUser.getName();
			app.remove(NewUser);
		}
		else {
			name = login.getname();
		}
		
		if (guest == false) {
			ModeSelect mode = new ModeSelect();
			app.add(mode);
			app.revalidate();
			while(mode.getDone() != true) {
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			app.remove(mode);
		}
	}
	
	public static void main(String[] args) {
		new Main();
	}
}
